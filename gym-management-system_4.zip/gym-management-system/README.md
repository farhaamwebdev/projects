# Ironboard — Fitness Studio Management System

A complete gym/studio management app: authentication, member profiles, class
scheduling, payment tracking, trainer assignments, attendance history, and
automated reminders. Node/Express + SQLite backend, no-build vanilla JS
frontend. Runs entirely on your machine — no external services required to
try it out.

## Stack
- **Backend:** Node.js, Express, SQLite (`better-sqlite3`), JWT auth, bcrypt password hashing, `node-cron` for scheduled reminders
- **Frontend:** Plain HTML/CSS/JS single-page app served as static files (no build step, no framework)
- **Database:** a single `gym.db` SQLite file — comes pre-seeded with demo data

## Quick start (in VS Code) — setting this up for a real client

1. Open this folder in VS Code (`File > Open Folder…`).
2. Open a terminal (`` Ctrl+` ``) and install dependencies:
   ```bash
   npm install
   ```
3. Copy the environment template and set a real JWT secret:
   ```bash
   cp .env.example .env
   ```
   Open `.env` and replace `JWT_SECRET` with a long random string.
4. Run the setup wizard — this is what creates the gym's branding and your
   own admin login. **No demo data is added**; you (or the gym owner) add
   real members, trainers, and classes from inside the app.
   ```bash
   npm run setup
   ```
   You'll be asked for the gym name, a tagline, and your admin email/password.
   Two starter membership plans (Basic $79/mo, Premium $129/mo) are created
   so the system isn't empty — rename, reprice, or delete them from
   **Settings** once you're logged in; pricing is entirely up to the gym owner.
5. Start the server:
   ```bash
   npm start
   ```
6. Open **http://localhost:4000**, log in with the admin email/password you
   just set, and start adding real members, trainers, and classes.

Run `npm run dev` instead of `npm start` during development — it restarts
the server automatically on file changes (Node's built-in `--watch`).

### Just want to poke around with sample data first?
```bash
npm run seed:demo
```
This loads sample members, trainers, classes, and payments — **for your own
testing only**. Never run this against a real client's deployment; delete
`gym.db` and run `npm run setup` instead when you're ready to hand it over.

## What's included

- **Auth** — JWT-based login/registration, bcrypt-hashed passwords, three
  roles (admin, trainer, member) with route-level permission checks.
- **Studio branding** — gym name and tagline are set during setup and
  editable any time from **Settings**; they appear on the login screen,
  browser tab title, and sidebar. Nothing is hardcoded to "Ironboard" except
  a small "Powered by" credit line.
- **Configurable pricing** — membership plans (name, price, description)
  are a catalog the gym owner fully controls from Settings: add, reprice, or
  retire plans any time. Individual members can also be given a custom rate
  that overrides the plan price, for one-off deals or negotiated pricing.
- **Dark / light theme** — a toggle on the login screen and in the sidebar
  switches the whole UI between a dark "scoreboard" theme and a bright
  theme, persisted per browser.
- **Member profiles** — self-service registration, admin-managed member
  records, membership plans and rates, status (active/paused/cancelled).
  The system ships with zero demo members — the gym populates its own.
- **Class scheduling** — admins create/edit/cancel classes, assign a
  trainer, set capacity and location; members browse and book; live
  fill-rate bars show how full each class is.
- **Trainer assignments** — trainer accounts see only their own assigned
  classes and rosters; admins assign trainers per class.
- **Attendance history** — bookings track booked/attended/no-show/cancelled;
  staff mark attendance from the roster view; members see their own
  history.
- **Payment tracking** — admins record payments and refunds, see a revenue
  summary (this month, total, pending, overdue members); members see their
  own payment history.
- **Automated reminders** — an hourly background job (`node-cron`) emails
  (currently: logs to console/`reminders_log` table) members about classes
  starting within 24 hours and payments due within 3 days. Admins can also
  trigger a sweep on demand from the Reminders tab.

## Wiring up real notifications

`src/services/reminderService.js` has a single `sendNotification()` function
that currently just logs to the console and to the `reminders_log` table.
Swap its body for a real provider call (e.g. SendGrid, Postmark, Twilio) and
every reminder in the app will start sending for real — no other code needs
to change.

## Project structure

```
gym-management-system/
├── src/
│   ├── server.js            # Express app entrypoint
│   ├── db.js                # SQLite schema + demo seed data
│   ├── middleware/auth.js   # JWT verification + role guards
│   ├── routes/               # auth, members, classes, bookings, payments, trainers, reminders
│   └── services/reminderService.js
├── public/                  # Static frontend (index.html, app.js, styles.css)
├── .env.example
└── package.json
```

## API overview

All routes except `/api/auth/*` and `/api/health` require an
`Authorization: Bearer <token>` header.

| Method | Path                     | Who            | Purpose |
|--------|--------------------------|----------------|---------|
| POST   | /api/auth/register       | public         | Self-service member signup |
| POST   | /api/auth/login          | public         | Login, returns JWT |
| GET    | /api/members             | admin/trainer  | List members |
| GET    | /api/members/:id         | self/staff     | Member profile + history |
| POST   | /api/members             | admin          | Create a member |
| PATCH  | /api/members/:id         | self/admin     | Update member |
| GET    | /api/classes             | any            | List classes |
| POST   | /api/classes             | admin          | Schedule a class |
| PATCH  | /api/classes/:id         | admin          | Edit/cancel a class |
| POST   | /api/bookings             | member/admin   | Book a class |
| PATCH  | /api/bookings/:id         | staff/self     | Mark attendance / cancel |
| GET    | /api/payments             | any (scoped)   | Payment history |
| GET    | /api/payments/summary     | admin          | Revenue KPIs |
| POST   | /api/payments             | member/admin   | Record a payment |
| GET    | /api/trainers             | any            | Trainer roster |
| POST   | /api/trainers             | admin          | Add a trainer |
| POST   | /api/reminders/run        | admin          | Trigger reminder sweep |
| GET    | /api/reminders/log        | admin          | Recent reminders sent |

## Deploying for a client

- Swap SQLite for Postgres/MySQL by replacing `src/db.js` (the rest of the
  app talks to it through plain SQL, so the surface area to change is
  small).
- Put the app behind HTTPS (e.g. Caddy, nginx, or a platform like Render/
  Fly.io/Railway) and set a strong `JWT_SECRET`.
- Wire up a real payment processor (Stripe, Square) in `routes/payments.js`
  instead of the manual "record a payment" flow, if you want online
  checkout rather than staff-entered payments.
- Wire up `sendNotification()` in `reminderService.js` to a real email/SMS
  provider.
