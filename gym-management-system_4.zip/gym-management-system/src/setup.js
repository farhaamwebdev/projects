/* Interactive first-run setup for a real client.
 * Creates the gym's own admin login and branding — no demo data.
 * Run with: npm run setup
 */
const readline = require('readline');
const { setupStudio } = require('./db');

const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
const ask = (q) => new Promise((resolve) => rl.question(q, resolve));
const askHidden = (q) => new Promise((resolve) => {
  // Simple hidden input for the password prompt (works in most terminals).
  const stdin = process.stdin;
  process.stdout.write(q);
  let input = '';
  stdin.setRawMode && stdin.setRawMode(true);
  stdin.resume();
  stdin.setEncoding('utf8');
  const onData = (char) => {
    char = char.toString();
    if (char === '\n' || char === '\r' || char === '\u0004') {
      stdin.setRawMode && stdin.setRawMode(false);
      stdin.pause();
      stdin.removeListener('data', onData);
      process.stdout.write('\n');
      resolve(input);
    } else if (char === '\u0003') {
      process.exit(1);
    } else if (char === '\u007f') {
      input = input.slice(0, -1);
    } else {
      input += char;
    }
  };
  stdin.on('data', onData);
});

async function main() {
  console.log('\n=== Studio setup ===');
  console.log("This creates your gym's branding and your own admin login.");
  console.log('No demo members, classes, or payments are added — you start with a clean system.\n');

  const gymName = (await ask('Gym / studio name: ')).trim() || 'My Gym';
  const tagline = (await ask('Tagline (optional, press enter to skip): ')).trim();
  const adminName = (await ask('Your name (admin account): ')).trim() || 'Admin';
  const adminEmail = (await ask('Your admin login email: ')).trim();
  let adminPassword = await askHidden('Choose an admin password (min 6 chars): ');

  if (!adminEmail || !adminEmail.includes('@')) {
    console.error('\nA valid email is required. Run "npm run setup" again.');
    rl.close();
    process.exit(1);
  }
  if (!adminPassword || adminPassword.length < 6) {
    console.error('\nPassword must be at least 6 characters. Run "npm run setup" again.');
    rl.close();
    process.exit(1);
  }

  try {
    setupStudio({ gymName, tagline, adminName, adminEmail, adminPassword });
    console.log(`\nAll set. "${gymName}" is ready.`);
    console.log(`Log in at http://localhost:${process.env.PORT || 4000} with:`);
    console.log(`  ${adminEmail} / (the password you just entered)`);
    console.log('\nTwo starter membership plans (Basic, Premium) were created — rename, reprice, or delete them from Settings once you log in.');
  } catch (err) {
    console.error(`\nSetup failed: ${err.message}`);
    process.exit(1);
  }
  rl.close();
}

main();
