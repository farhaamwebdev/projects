const cron = require('node-cron');
const { db } = require('../db');

// Swap this out for a real provider (SendGrid, Twilio, Postmark, etc).
// Kept as a pluggable function so wiring up a real sender is a one-line change.
function sendNotification({ to, subject, message }) {
  console.log(`[REMINDER -> ${to}] ${subject}: ${message}`);
  return true;
}

function logReminder(type, targetId, recipient, message) {
  db.prepare(`
    INSERT INTO reminders_log (type, target_id, recipient, message) VALUES (?, ?, ?, ?)
  `).run(type, targetId, recipient, message);
}

// Class reminders: notify members booked into classes starting within the next N hours,
// only once per booking (checked via reminders_log).
function runClassReminders() {
  const hoursBefore = Number(process.env.REMINDER_HOURS_BEFORE_CLASS || 24);
  const windowEnd = new Date(Date.now() + hoursBefore * 3600 * 1000).toISOString();

  const upcoming = db.prepare(`
    SELECT b.id as booking_id, c.id as class_id, c.name as class_name, c.start_time,
           u.name as member_name, u.email as member_email
    FROM bookings b
    JOIN classes c ON c.id = b.class_id
    JOIN members m ON m.id = b.member_id
    JOIN users u ON u.id = m.user_id
    WHERE b.status = 'booked'
      AND c.status = 'scheduled'
      AND c.start_time <= ?
      AND c.start_time >= datetime('now')
      AND NOT EXISTS (
        SELECT 1 FROM reminders_log r WHERE r.type = 'class' AND r.target_id = b.id
      )
  `).all(windowEnd);

  for (const row of upcoming) {
    const message = `Reminder: your class "${row.class_name}" starts at ${row.start_time}.`;
    sendNotification({ to: row.member_email, subject: 'Upcoming class reminder', message });
    logReminder('class', row.booking_id, row.member_email, message);
  }
  return upcoming.length;
}

// Payment reminders: notify members whose next_payment_due is within N days and still active.
function runPaymentReminders() {
  const daysBefore = Number(process.env.REMINDER_DAYS_BEFORE_PAYMENT || 3);

  const due = db.prepare(`
    SELECT m.id as member_id, m.next_payment_due, u.name, u.email
    FROM members m JOIN users u ON u.id = m.user_id
    WHERE m.status = 'active'
      AND m.next_payment_due IS NOT NULL
      AND m.next_payment_due <= date('now', '+' || ? || ' days')
      AND m.next_payment_due >= date('now')
      AND NOT EXISTS (
        SELECT 1 FROM reminders_log r
        WHERE r.type = 'payment' AND r.target_id = m.id
          AND date(r.sent_at) = date('now')
      )
  `).all(daysBefore);

  for (const row of due) {
    const message = `Reminder: your membership payment is due on ${row.next_payment_due}.`;
    sendNotification({ to: row.email, subject: 'Payment due soon', message });
    logReminder('payment', row.member_id, row.email, message);
  }
  return due.length;
}

function runAllReminders() {
  const classCount = runClassReminders();
  const paymentCount = runPaymentReminders();
  console.log(`Reminder sweep: ${classCount} class reminders, ${paymentCount} payment reminders sent.`);
  return { classCount, paymentCount };
}

// Schedule a sweep every hour. Also exported for manual/admin-triggered runs.
function startScheduledReminders() {
  cron.schedule('0 * * * *', runAllReminders);
  console.log('Reminder scheduler started (runs hourly).');
}

module.exports = { runAllReminders, runClassReminders, runPaymentReminders, startScheduledReminders };
