const path = require('path');
const bcrypt = require('bcryptjs');
const Database = require('better-sqlite3');

const DB_PATH = path.join(__dirname, '..', 'gym.db');
const db = new Database(DB_PATH);
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');

// ---------- Schema ----------
db.exec(`
CREATE TABLE IF NOT EXISTS users (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  name          TEXT NOT NULL,
  email         TEXT NOT NULL UNIQUE,
  phone         TEXT,
  password_hash TEXT NOT NULL,
  role          TEXT NOT NULL CHECK(role IN ('admin','trainer','member')),
  created_at    TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS members (
  id              INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id         INTEGER NOT NULL UNIQUE REFERENCES users(id) ON DELETE CASCADE,
  membership_plan TEXT NOT NULL DEFAULT 'Basic',
  monthly_rate    REAL NOT NULL DEFAULT 0,
  join_date       TEXT NOT NULL DEFAULT (date('now')),
  status          TEXT NOT NULL DEFAULT 'active' CHECK(status IN ('active','paused','cancelled')),
  next_payment_due TEXT
);

CREATE TABLE IF NOT EXISTS trainers (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id    INTEGER NOT NULL UNIQUE REFERENCES users(id) ON DELETE CASCADE,
  specialty  TEXT,
  bio        TEXT
);

CREATE TABLE IF NOT EXISTS classes (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  name        TEXT NOT NULL,
  description TEXT,
  trainer_id  INTEGER REFERENCES trainers(id) ON DELETE SET NULL,
  start_time  TEXT NOT NULL,   -- ISO datetime
  end_time    TEXT NOT NULL,   -- ISO datetime
  capacity    INTEGER NOT NULL DEFAULT 12,
  location    TEXT DEFAULT 'Main Studio',
  status      TEXT NOT NULL DEFAULT 'scheduled' CHECK(status IN ('scheduled','cancelled','completed'))
);

CREATE TABLE IF NOT EXISTS bookings (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  class_id    INTEGER NOT NULL REFERENCES classes(id) ON DELETE CASCADE,
  member_id   INTEGER NOT NULL REFERENCES members(id) ON DELETE CASCADE,
  booked_at   TEXT NOT NULL DEFAULT (datetime('now')),
  status      TEXT NOT NULL DEFAULT 'booked' CHECK(status IN ('booked','attended','no_show','cancelled')),
  UNIQUE(class_id, member_id)
);

CREATE TABLE IF NOT EXISTS payments (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  member_id   INTEGER NOT NULL REFERENCES members(id) ON DELETE CASCADE,
  amount      REAL NOT NULL,
  method      TEXT NOT NULL DEFAULT 'card',
  status      TEXT NOT NULL DEFAULT 'paid' CHECK(status IN ('paid','pending','failed','refunded')),
  paid_at     TEXT NOT NULL DEFAULT (datetime('now')),
  notes       TEXT
);

CREATE TABLE IF NOT EXISTS settings (
  id          INTEGER PRIMARY KEY CHECK (id = 1),
  gym_name    TEXT NOT NULL DEFAULT 'My Gym',
  tagline     TEXT NOT NULL DEFAULT 'Strength. Community. Results.',
  currency    TEXT NOT NULL DEFAULT 'USD',
  updated_at  TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS membership_plans (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  name        TEXT NOT NULL,
  monthly_rate REAL NOT NULL DEFAULT 0,
  description TEXT,
  active      INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE IF NOT EXISTS reminders_log (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  type        TEXT NOT NULL,        -- 'class' | 'payment'
  target_id   INTEGER NOT NULL,     -- class_id or member_id
  recipient   TEXT NOT NULL,
  message     TEXT NOT NULL,
  sent_at     TEXT NOT NULL DEFAULT (datetime('now'))
);
`);

// ---------- Ensure a settings row always exists ----------
function ensureSettings() {
  const existing = db.prepare('SELECT id FROM settings WHERE id = 1').get();
  if (!existing) {
    db.prepare(`INSERT INTO settings (id, gym_name, tagline) VALUES (1, 'My Gym', 'Strength. Community. Results.')`).run();
  }
}
ensureSettings();

// ---------- Real onboarding: create the studio's own admin account ----------
// This is what you actually run when handing the system to a real gym —
// no demo members, no demo classes, just a working admin login and a
// couple of starter membership plans the owner can rename or delete.
function setupStudio({ gymName, tagline, adminName, adminEmail, adminPassword }) {
  const existingAdmin = db.prepare(`SELECT id FROM users WHERE role = 'admin' LIMIT 1`).get();
  if (existingAdmin) {
    throw new Error('An admin account already exists. Delete gym.db first if you want to start over.');
  }

  const hash = bcrypt.hashSync(adminPassword, 10);
  const tx = db.transaction(() => {
    db.prepare(`
      INSERT INTO settings (id, gym_name, tagline) VALUES (1, ?, ?)
      ON CONFLICT(id) DO UPDATE SET gym_name = excluded.gym_name, tagline = excluded.tagline
    `).run(gymName, tagline || 'Strength. Community. Results.');

    db.prepare(`
      INSERT INTO users (name, email, phone, password_hash, role) VALUES (?, ?, NULL, ?, 'admin')
    `).run(adminName, adminEmail, hash);

    // Starter plan catalog — fully editable/deletable from Settings once logged in.
    const planCount = db.prepare('SELECT COUNT(*) c FROM membership_plans').get().c;
    if (planCount === 0) {
      const insertPlan = db.prepare('INSERT INTO membership_plans (name, monthly_rate, description) VALUES (?, ?, ?)');
      insertPlan.run('Basic', 79, 'Gym floor access');
      insertPlan.run('Premium', 129, 'Gym floor + unlimited classes');
    }
  });
  tx();
}

// ---------- Optional demo data — for YOUR OWN testing only, never for a real client ----------
function seedDemoData() {
  const userCount = db.prepare('SELECT COUNT(*) c FROM users').get().c;
  if (userCount > 0) {
    console.log('DB already has data — skipping demo seed. Delete gym.db first to reseed.');
    return;
  }

  const insertUser = db.prepare(`INSERT INTO users (name, email, phone, password_hash, role) VALUES (?, ?, ?, ?, ?)`);
  const hash = (pw) => bcrypt.hashSync(pw, 10);

  db.prepare(`INSERT INTO settings (id, gym_name, tagline) VALUES (1, 'Ironboard Demo Gym', 'A sample studio for testing only') ON CONFLICT(id) DO UPDATE SET gym_name = excluded.gym_name, tagline = excluded.tagline`).run();

  insertUser.run('Studio Admin', 'admin@studio.com', '555-0100', hash('admin123'), 'admin');
  const trainer1User = insertUser.run('Jess Rivera', 'jess@studio.com', '555-0101', hash('trainer123'), 'trainer').lastInsertRowid;
  const trainer2User = insertUser.run('Marcus Lee', 'marcus@studio.com', '555-0102', hash('trainer123'), 'trainer').lastInsertRowid;

  const insertTrainer = db.prepare('INSERT INTO trainers (user_id, specialty, bio) VALUES (?, ?, ?)');
  const trainer1 = insertTrainer.run(trainer1User, 'HIIT / Strength', 'Certified strength coach, 8 years experience.').lastInsertRowid;
  const trainer2 = insertTrainer.run(trainer2User, 'Yoga / Mobility', 'RYT-500 yoga instructor.').lastInsertRowid;

  const insertPlan = db.prepare('INSERT INTO membership_plans (name, monthly_rate, description) VALUES (?, ?, ?)');
  const basicPlan = insertPlan.run('Basic', 79, 'Gym floor access').lastInsertRowid;
  const premiumPlan = insertPlan.run('Premium', 129, 'Gym floor + unlimited classes').lastInsertRowid;

  const memberUsers = [['Alex Chen', 'alex@example.com', '555-0201'], ['Priya Patel', 'priya@example.com', '555-0202'], ['Sam Johnson', 'sam@example.com', '555-0203']];
  const insertMember = db.prepare(`INSERT INTO members (user_id, membership_plan, monthly_rate, next_payment_due) VALUES (?, ?, ?, date('now', '+' || ? || ' days'))`);
  const memberIds = memberUsers.map(([name, email, phone], i) => {
    const uid = insertUser.run(name, email, phone, hash('member123'), 'member').lastInsertRowid;
    return insertMember.run(uid, i === 0 ? 'Premium' : 'Basic', i === 0 ? 129 : 79, 30 - i * 5).lastInsertRowid;
  });

  const insertClass = db.prepare(`INSERT INTO classes (name, description, trainer_id, start_time, end_time, capacity, location) VALUES (?, ?, ?, ?, ?, ?, ?)`);
  const classIds = [
    insertClass.run('Morning HIIT', 'High-intensity interval training.', trainer1, new Date(Date.now() + 86400000).toISOString(), new Date(Date.now() + 86400000 + 3600000).toISOString(), 15, 'Studio A').lastInsertRowid,
    insertClass.run('Vinyasa Flow', 'All-levels flowing yoga.', trainer2, new Date(Date.now() + 2 * 86400000).toISOString(), new Date(Date.now() + 2 * 86400000 + 3600000).toISOString(), 20, 'Studio B').lastInsertRowid,
    insertClass.run('Strength Fundamentals', 'Barbell basics.', trainer1, new Date(Date.now() + 3 * 86400000).toISOString(), new Date(Date.now() + 3 * 86400000 + 3600000).toISOString(), 10, 'Weight Room').lastInsertRowid,
  ];

  const insertBooking = db.prepare('INSERT OR IGNORE INTO bookings (class_id, member_id, status) VALUES (?, ?, ?)');
  insertBooking.run(classIds[0], memberIds[0], 'booked');
  insertBooking.run(classIds[1], memberIds[1], 'booked');
  insertBooking.run(classIds[0], memberIds[2], 'booked');

  const insertPayment = db.prepare(`INSERT INTO payments (member_id, amount, method, status, notes) VALUES (?, ?, ?, ?, ?)`);
  insertPayment.run(memberIds[0], 129, 'card', 'paid', 'Premium plan — monthly');
  insertPayment.run(memberIds[1], 79, 'card', 'paid', 'Basic plan — monthly');
  insertPayment.run(memberIds[2], 79, 'card', 'pending', 'Basic plan — monthly');

  console.log('Demo data loaded (for your own testing only — do not ship this to a client).');
  console.log('Login as admin:   admin@studio.com / admin123');
  console.log('Login as trainer: jess@studio.com / trainer123');
  console.log('Login as member:  alex@example.com / member123');
}

module.exports = { db, setupStudio, seedDemoData };
