const express = require('express');
const bcrypt = require('bcryptjs');
const { db } = require('../db');
const { authRequired, requireRole } = require('../middleware/auth');

const router = express.Router();
router.use(authRequired);

const TRAINER_VIEW = `
  SELECT t.id, t.specialty, t.bio, u.id as user_id, u.name, u.email, u.phone
  FROM trainers t JOIN users u ON u.id = t.user_id
`;

// GET /api/trainers — everyone can see the trainer roster
router.get('/', (req, res) => {
  res.json(db.prepare(`${TRAINER_VIEW} ORDER BY u.name`).all());
});

// GET /api/trainers/:id — includes their upcoming class assignments
router.get('/:id', (req, res) => {
  const row = db.prepare(`${TRAINER_VIEW} WHERE t.id = ?`).get(req.params.id);
  if (!row) return res.status(404).json({ error: 'Trainer not found' });

  const classes = db.prepare(`
    SELECT id, name, start_time, end_time, capacity, status,
           (SELECT COUNT(*) FROM bookings b WHERE b.class_id = classes.id AND b.status IN ('booked','attended')) as booked_count
    FROM classes WHERE trainer_id = ? ORDER BY start_time
  `).all(req.params.id);

  res.json({ ...row, classes });
});

// POST /api/trainers — admin creates a trainer account
router.post('/', requireRole('admin'), (req, res) => {
  const { name, email, phone, password, specialty, bio } = req.body;
  if (!name || !email || !password) return res.status(400).json({ error: 'name, email, password required' });

  const existing = db.prepare('SELECT id FROM users WHERE email = ?').get(email);
  if (existing) return res.status(409).json({ error: 'Email already registered' });

  const hash = bcrypt.hashSync(password, 10);
  const tx = db.transaction(() => {
    const userId = db.prepare(`
      INSERT INTO users (name, email, phone, password_hash, role) VALUES (?, ?, ?, ?, 'trainer')
    `).run(name, email, phone || null, hash).lastInsertRowid;
    return db.prepare('INSERT INTO trainers (user_id, specialty, bio) VALUES (?, ?, ?)').run(userId, specialty || null, bio || null).lastInsertRowid;
  });

  const trainerId = tx();
  res.status(201).json(db.prepare(`${TRAINER_VIEW} WHERE t.id = ?`).get(trainerId));
});

// PATCH /api/trainers/:id — admin edits, or trainer edits own bio/specialty
router.patch('/:id', (req, res) => {
  const id = Number(req.params.id);
  const isSelf = req.user.role === 'trainer' && req.user.trainerId === id;
  if (!isSelf && req.user.role !== 'admin') return res.status(403).json({ error: 'Not allowed' });

  const { specialty, bio } = req.body;
  if (specialty !== undefined) db.prepare('UPDATE trainers SET specialty = ? WHERE id = ?').run(specialty, id);
  if (bio !== undefined) db.prepare('UPDATE trainers SET bio = ? WHERE id = ?').run(bio, id);

  res.json(db.prepare(`${TRAINER_VIEW} WHERE t.id = ?`).get(id));
});

module.exports = router;
