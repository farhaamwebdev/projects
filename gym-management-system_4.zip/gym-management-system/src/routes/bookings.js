const express = require('express');
const { db } = require('../db');
const { authRequired, requireRole } = require('../middleware/auth');

const router = express.Router();
router.use(authRequired);

// POST /api/bookings  — member books a class for themselves (or admin books on their behalf)
router.post('/', (req, res) => {
  const { classId, memberId } = req.body;
  const targetMemberId = req.user.role === 'member' ? req.user.memberId : memberId;
  if (!classId || !targetMemberId) return res.status(400).json({ error: 'classId and memberId are required' });

  const klass = db.prepare('SELECT * FROM classes WHERE id = ?').get(classId);
  if (!klass) return res.status(404).json({ error: 'Class not found' });
  if (klass.status === 'cancelled') return res.status(400).json({ error: 'Class is cancelled' });

  const bookedCount = db.prepare(`
    SELECT COUNT(*) c FROM bookings WHERE class_id = ? AND status IN ('booked','attended')
  `).get(classId).c;
  if (bookedCount >= klass.capacity) return res.status(409).json({ error: 'Class is full' });

  try {
    const result = db.prepare(`
      INSERT INTO bookings (class_id, member_id, status) VALUES (?, ?, 'booked')
    `).run(classId, targetMemberId);
    res.status(201).json({ id: result.lastInsertRowid, classId, memberId: targetMemberId, status: 'booked' });
  } catch (err) {
    if (String(err.message).includes('UNIQUE')) {
      return res.status(409).json({ error: 'Already booked into this class' });
    }
    res.status(500).json({ error: 'Booking failed' });
  }
});

// PATCH /api/bookings/:id  — mark attended / no_show (admin/trainer), or member cancels their own
router.patch('/:id', (req, res) => {
  const id = Number(req.params.id);
  const booking = db.prepare('SELECT * FROM bookings WHERE id = ?').get(id);
  if (!booking) return res.status(404).json({ error: 'Booking not found' });

  const { status } = req.body; // 'attended' | 'no_show' | 'cancelled'
  if (!['attended', 'no_show', 'cancelled', 'booked'].includes(status)) {
    return res.status(400).json({ error: 'Invalid status' });
  }

  if (status === 'cancelled') {
    const isSelf = req.user.role === 'member' && req.user.memberId === booking.member_id;
    if (!isSelf && !['admin', 'trainer'].includes(req.user.role)) {
      return res.status(403).json({ error: 'Not allowed' });
    }
  } else if (!['admin', 'trainer'].includes(req.user.role)) {
    return res.status(403).json({ error: 'Only staff can mark attendance' });
  }

  db.prepare('UPDATE bookings SET status = ? WHERE id = ?').run(status, id);
  res.json({ id, status });
});

// GET /api/bookings/class/:classId  — roster for a class (staff)
router.get('/class/:classId', requireRole('admin', 'trainer'), (req, res) => {
  const rows = db.prepare(`
    SELECT b.id, b.status, b.booked_at, m.id as member_id, u.name, u.email
    FROM bookings b JOIN members m ON m.id = b.member_id JOIN users u ON u.id = m.user_id
    WHERE b.class_id = ? ORDER BY b.booked_at
  `).all(req.params.classId);
  res.json(rows);
});

module.exports = router;
