const express = require('express');
const { db } = require('../db');
const { authRequired, requireRole } = require('../middleware/auth');

const router = express.Router();

// GET /api/settings — public (needed to brand the login screen before auth)
router.get('/', (req, res) => {
  const row = db.prepare('SELECT gym_name, tagline, currency FROM settings WHERE id = 1').get();
  res.json(row || { gym_name: 'My Gym', tagline: '', currency: 'USD' });
});

// PATCH /api/settings — admin only
router.patch('/', authRequired, requireRole('admin'), (req, res) => {
  const { gymName, tagline, currency } = req.body;
  const current = db.prepare('SELECT * FROM settings WHERE id = 1').get();
  db.prepare(`
    UPDATE settings SET
      gym_name = ?, tagline = ?, currency = ?, updated_at = datetime('now')
    WHERE id = 1
  `).run(
    gymName !== undefined ? gymName : current.gym_name,
    tagline !== undefined ? tagline : current.tagline,
    currency !== undefined ? currency : current.currency
  );
  res.json(db.prepare('SELECT gym_name, tagline, currency FROM settings WHERE id = 1').get());
});

module.exports = router;
