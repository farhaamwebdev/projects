const express = require('express');
const { db } = require('../db');
const { authRequired, requireRole } = require('../middleware/auth');
const { runAllReminders } = require('../services/reminderService');

const router = express.Router();
router.use(authRequired, requireRole('admin'));

// POST /api/reminders/run — manually trigger a reminder sweep (in addition to the hourly cron job)
router.post('/run', (req, res) => {
  const result = runAllReminders();
  res.json(result);
});

// GET /api/reminders/log — recent reminders sent
router.get('/log', (req, res) => {
  const rows = db.prepare('SELECT * FROM reminders_log ORDER BY sent_at DESC LIMIT 100').all();
  res.json(rows);
});

module.exports = router;
