const express = require('express');
const { db } = require('../db');
const { authRequired, requireRole } = require('../middleware/auth');

const router = express.Router();
router.use(authRequired);

const CLASS_VIEW = `
  SELECT c.id, c.name, c.description, c.start_time, c.end_time, c.capacity, c.location, c.status,
         t.id as trainer_id, ut.name as trainer_name,
         (SELECT COUNT(*) FROM bookings b WHERE b.class_id = c.id AND b.status IN ('booked','attended')) as booked_count
  FROM classes c
  LEFT JOIN trainers t ON t.id = c.trainer_id
  LEFT JOIN users ut ON ut.id = t.user_id
`;

// GET /api/classes  — all roles can view the schedule
router.get('/', (req, res) => {
  const { from, to } = req.query;
  let sql = CLASS_VIEW;
  const params = [];
  if (from || to) {
    sql += ' WHERE 1=1';
    if (from) { sql += ' AND c.start_time >= ?'; params.push(from); }
    if (to) { sql += ' AND c.start_time <= ?'; params.push(to); }
  }
  sql += ' ORDER BY c.start_time';
  res.json(db.prepare(sql).all(...params));
});

// GET /api/classes/:id
router.get('/:id', (req, res) => {
  const row = db.prepare(`${CLASS_VIEW} WHERE c.id = ?`).get(req.params.id);
  if (!row) return res.status(404).json({ error: 'Class not found' });

  const roster = db.prepare(`
    SELECT b.id as booking_id, b.status, m.id as member_id, u.name, u.email
    FROM bookings b
    JOIN members m ON m.id = b.member_id
    JOIN users u ON u.id = m.user_id
    WHERE b.class_id = ?
    ORDER BY b.booked_at
  `).all(req.params.id);

  res.json({ ...row, roster });
});

// POST /api/classes  (admin only — schedule a class + assign a trainer)
router.post('/', requireRole('admin'), (req, res) => {
  const { name, description, trainerId, startTime, endTime, capacity, location } = req.body;
  if (!name || !startTime || !endTime) {
    return res.status(400).json({ error: 'name, startTime, endTime are required' });
  }
  const result = db.prepare(`
    INSERT INTO classes (name, description, trainer_id, start_time, end_time, capacity, location)
    VALUES (?, ?, ?, ?, ?, ?, ?)
  `).run(name, description || null, trainerId || null, startTime, endTime, capacity || 12, location || 'Main Studio');

  const row = db.prepare(`${CLASS_VIEW} WHERE c.id = ?`).get(result.lastInsertRowid);
  res.status(201).json(row);
});

// PATCH /api/classes/:id  (admin — reschedule, reassign trainer, cancel, etc.)
router.patch('/:id', requireRole('admin'), (req, res) => {
  const id = Number(req.params.id);
  const existing = db.prepare('SELECT * FROM classes WHERE id = ?').get(id);
  if (!existing) return res.status(404).json({ error: 'Class not found' });

  const fields = ['name', 'description', 'trainer_id', 'start_time', 'end_time', 'capacity', 'location', 'status'];
  const bodyMap = {
    name: req.body.name, description: req.body.description, trainer_id: req.body.trainerId,
    start_time: req.body.startTime, end_time: req.body.endTime, capacity: req.body.capacity,
    location: req.body.location, status: req.body.status,
  };
  const updates = [];
  const params = [];
  for (const f of fields) {
    if (bodyMap[f] !== undefined) { updates.push(`${f} = ?`); params.push(bodyMap[f]); }
  }
  if (updates.length) {
    params.push(id);
    db.prepare(`UPDATE classes SET ${updates.join(', ')} WHERE id = ?`).run(...params);
  }
  const row = db.prepare(`${CLASS_VIEW} WHERE c.id = ?`).get(id);
  res.json(row);
});

// DELETE /api/classes/:id (admin)
router.delete('/:id', requireRole('admin'), (req, res) => {
  const info = db.prepare('DELETE FROM classes WHERE id = ?').run(req.params.id);
  if (info.changes === 0) return res.status(404).json({ error: 'Class not found' });
  res.status(204).end();
});

module.exports = router;
