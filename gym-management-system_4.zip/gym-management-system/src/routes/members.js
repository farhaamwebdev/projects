const express = require('express');
const bcrypt = require('bcryptjs');
const { db } = require('../db');
const { authRequired, requireRole } = require('../middleware/auth');

const router = express.Router();
router.use(authRequired);

const MEMBER_VIEW = `
  SELECT m.id, m.membership_plan, m.monthly_rate, m.join_date, m.status, m.next_payment_due,
         u.id as user_id, u.name, u.email, u.phone
  FROM members m JOIN users u ON u.id = m.user_id
`;

// GET /api/members  (admin/trainer only)
router.get('/', requireRole('admin', 'trainer'), (req, res) => {
  const rows = db.prepare(`${MEMBER_VIEW} ORDER BY u.name`).all();
  res.json(rows);
});

// GET /api/members/:id  (self, or admin/trainer)
router.get('/:id', (req, res) => {
  const id = Number(req.params.id);
  if (req.user.role === 'member' && req.user.memberId !== id) {
    return res.status(403).json({ error: 'Cannot view another member profile' });
  }
  const row = db.prepare(`${MEMBER_VIEW} WHERE m.id = ?`).get(id);
  if (!row) return res.status(404).json({ error: 'Member not found' });

  const attendance = db.prepare(`
    SELECT b.id, b.status, b.booked_at, c.name as class_name, c.start_time
    FROM bookings b JOIN classes c ON c.id = b.class_id
    WHERE b.member_id = ? ORDER BY c.start_time DESC
  `).all(id);

  const payments = db.prepare(`
    SELECT id, amount, method, status, paid_at, notes FROM payments
    WHERE member_id = ? ORDER BY paid_at DESC
  `).all(id);

  res.json({ ...row, attendance, payments });
});

// PATCH /api/members/:id  (admin, or self for limited fields)
router.patch('/:id', (req, res) => {
  const id = Number(req.params.id);
  const isSelf = req.user.role === 'member' && req.user.memberId === id;
  if (!isSelf && req.user.role !== 'admin') {
    return res.status(403).json({ error: 'Not allowed' });
  }

  const member = db.prepare('SELECT * FROM members WHERE id = ?').get(id);
  if (!member) return res.status(404).json({ error: 'Member not found' });

  const { membershipPlan, monthlyRate, status, phone } = req.body;

  if (phone !== undefined) {
    db.prepare('UPDATE users SET phone = ? WHERE id = ?').run(phone, member.user_id);
  }
  if (!isSelf) {
    if (membershipPlan !== undefined) db.prepare('UPDATE members SET membership_plan = ? WHERE id = ?').run(membershipPlan, id);
    if (monthlyRate !== undefined) db.prepare('UPDATE members SET monthly_rate = ? WHERE id = ?').run(monthlyRate, id);
    if (status !== undefined) db.prepare('UPDATE members SET status = ? WHERE id = ?').run(status, id);
  }

  const row = db.prepare(`${MEMBER_VIEW} WHERE m.id = ?`).get(id);
  res.json(row);
});

// POST /api/members  (admin creates a member directly, e.g. walk-in signup)
router.post('/', requireRole('admin'), (req, res) => {
  const { name, email, phone, password, membershipPlan, monthlyRate } = req.body;
  if (!name || !email || !password) return res.status(400).json({ error: 'name, email, password required' });

  const existing = db.prepare('SELECT id FROM users WHERE email = ?').get(email);
  if (existing) return res.status(409).json({ error: 'Email already registered' });

  const hash = bcrypt.hashSync(password, 10);
  const tx = db.transaction(() => {
    const userId = db.prepare(`
      INSERT INTO users (name, email, phone, password_hash, role) VALUES (?, ?, ?, ?, 'member')
    `).run(name, email, phone || null, hash).lastInsertRowid;

    return db.prepare(`
      INSERT INTO members (user_id, membership_plan, monthly_rate, next_payment_due)
      VALUES (?, ?, ?, date('now', '+30 days'))
    `).run(userId, membershipPlan || 'Basic', monthlyRate || 79).lastInsertRowid;
  });

  const memberId = tx();
  const row = db.prepare(`${MEMBER_VIEW} WHERE m.id = ?`).get(memberId);
  res.status(201).json(row);
});

module.exports = router;
