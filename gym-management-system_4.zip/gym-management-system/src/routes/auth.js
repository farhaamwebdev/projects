const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { db } = require('../db');

const router = express.Router();

function signToken(user, extra = {}) {
  return jwt.sign(
    { id: user.id, name: user.name, email: user.email, role: user.role, ...extra },
    process.env.JWT_SECRET,
    { expiresIn: process.env.JWT_EXPIRES_IN || '12h' }
  );
}

// POST /api/auth/register  (self-service — always creates a "member")
router.post('/register', (req, res) => {
  const { name, email, phone, password, membershipPlan } = req.body;
  if (!name || !email || !password) {
    return res.status(400).json({ error: 'name, email, and password are required' });
  }

  const existing = db.prepare('SELECT id FROM users WHERE email = ?').get(email);
  if (existing) return res.status(409).json({ error: 'Email already registered' });

  const hash = bcrypt.hashSync(password, 10);
  // Look up the real price for this plan from the gym's own catalog (set in Settings)
  // rather than a hardcoded rate — this is what makes pricing owner-configurable.
  const planRow = db.prepare('SELECT * FROM membership_plans WHERE name = ? AND active = 1').get(membershipPlan);
  const plan = planRow ? planRow.name : (membershipPlan || 'Standard');
  const rate = planRow ? planRow.monthly_rate : 0;

  const tx = db.transaction(() => {
    const userId = db.prepare(`
      INSERT INTO users (name, email, phone, password_hash, role) VALUES (?, ?, ?, ?, 'member')
    `).run(name, email, phone || null, hash).lastInsertRowid;

    const memberId = db.prepare(`
      INSERT INTO members (user_id, membership_plan, monthly_rate, next_payment_due)
      VALUES (?, ?, ?, date('now', '+30 days'))
    `).run(userId, plan, rate).lastInsertRowid;

    return { userId, memberId };
  });

  const { userId, memberId } = tx();
  const user = { id: userId, name, email, role: 'member' };
  const token = signToken(user, { memberId });
  res.status(201).json({ token, user: { ...user, memberId } });
});

// POST /api/auth/login
router.post('/login', (req, res) => {
  const { email, password } = req.body;
  if (!email || !password) return res.status(400).json({ error: 'email and password are required' });

  const user = db.prepare('SELECT * FROM users WHERE email = ?').get(email);
  if (!user || !bcrypt.compareSync(password, user.password_hash)) {
    return res.status(401).json({ error: 'Invalid credentials' });
  }

  let extra = {};
  if (user.role === 'member') {
    const m = db.prepare('SELECT id FROM members WHERE user_id = ?').get(user.id);
    if (m) extra.memberId = m.id;
  } else if (user.role === 'trainer') {
    const t = db.prepare('SELECT id FROM trainers WHERE user_id = ?').get(user.id);
    if (t) extra.trainerId = t.id;
  }

  const token = signToken(user, extra);
  res.json({
    token,
    user: { id: user.id, name: user.name, email: user.email, role: user.role, ...extra },
  });
});

module.exports = router;
