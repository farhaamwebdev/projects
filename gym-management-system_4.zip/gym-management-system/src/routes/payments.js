const express = require('express');
const { db } = require('../db');
const { authRequired, requireRole } = require('../middleware/auth');

const router = express.Router();
router.use(authRequired);

// GET /api/payments  — admin: all payments; member: own payments only
router.get('/', (req, res) => {
  if (req.user.role === 'member') {
    const rows = db.prepare(`
      SELECT id, amount, method, status, paid_at, notes FROM payments
      WHERE member_id = ? ORDER BY paid_at DESC
    `).all(req.user.memberId);
    return res.json(rows);
  }
  const rows = db.prepare(`
    SELECT p.id, p.amount, p.method, p.status, p.paid_at, p.notes,
           m.id as member_id, u.name as member_name
    FROM payments p JOIN members m ON m.id = p.member_id JOIN users u ON u.id = m.user_id
    ORDER BY p.paid_at DESC
  `).all();
  res.json(rows);
});

// GET /api/payments/summary  — admin dashboard KPIs
router.get('/summary', requireRole('admin'), (req, res) => {
  const totalRevenue = db.prepare(`SELECT COALESCE(SUM(amount),0) t FROM payments WHERE status = 'paid'`).get().t;
  const pending = db.prepare(`SELECT COALESCE(SUM(amount),0) t, COUNT(*) c FROM payments WHERE status = 'pending'`).get();
  const monthRevenue = db.prepare(`
    SELECT COALESCE(SUM(amount),0) t FROM payments
    WHERE status = 'paid' AND strftime('%Y-%m', paid_at) = strftime('%Y-%m', 'now')
  `).get().t;
  const overdueMembers = db.prepare(`
    SELECT m.id, u.name, m.next_payment_due FROM members m JOIN users u ON u.id = m.user_id
    WHERE m.next_payment_due < date('now') AND m.status = 'active'
  `).all();

  res.json({ totalRevenue, pendingAmount: pending.t, pendingCount: pending.c, monthRevenue, overdueMembers });
});

// POST /api/payments  — admin records a payment (or a member "pays" — simulated charge)
router.post('/', (req, res) => {
  const { memberId, amount, method, status, notes } = req.body;
  const targetMemberId = req.user.role === 'member' ? req.user.memberId : memberId;
  if (!targetMemberId || amount === undefined) {
    return res.status(400).json({ error: 'memberId and amount are required' });
  }

  const result = db.prepare(`
    INSERT INTO payments (member_id, amount, method, status, notes)
    VALUES (?, ?, ?, ?, ?)
  `).run(targetMemberId, amount, method || 'card', status || 'paid', notes || null);

  // Push next_payment_due out by 30 days when a payment clears
  if ((status || 'paid') === 'paid') {
    db.prepare(`UPDATE members SET next_payment_due = date('now', '+30 days') WHERE id = ?`).run(targetMemberId);
  }

  res.status(201).json({ id: result.lastInsertRowid, memberId: targetMemberId, amount, status: status || 'paid' });
});

// PATCH /api/payments/:id  — admin updates status (e.g. mark refunded)
router.patch('/:id', requireRole('admin'), (req, res) => {
  const { status } = req.body;
  const info = db.prepare('UPDATE payments SET status = ? WHERE id = ?').run(status, req.params.id);
  if (info.changes === 0) return res.status(404).json({ error: 'Payment not found' });
  res.json({ id: Number(req.params.id), status });
});

module.exports = router;
