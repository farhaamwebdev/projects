const express = require('express');
const { db } = require('../db');
const { authRequired, requireRole } = require('../middleware/auth');

const router = express.Router();

// GET /api/plans — public (self-signup screen needs this before login)
router.get('/', (req, res) => {
  res.json(db.prepare('SELECT * FROM membership_plans WHERE active = 1 ORDER BY monthly_rate').all());
});

// POST /api/plans — admin creates a new plan (any price the gym owner wants)
router.post('/', authRequired, requireRole('admin'), (req, res) => {
  const { name, monthlyRate, description } = req.body;
  if (!name || monthlyRate === undefined) return res.status(400).json({ error: 'name and monthlyRate are required' });
  const result = db.prepare('INSERT INTO membership_plans (name, monthly_rate, description) VALUES (?, ?, ?)').run(name, monthlyRate, description || null);
  res.status(201).json(db.prepare('SELECT * FROM membership_plans WHERE id = ?').get(result.lastInsertRowid));
});

// PATCH /api/plans/:id — admin edits price/name at any time
router.patch('/:id', authRequired, requireRole('admin'), (req, res) => {
  const id = Number(req.params.id);
  const existing = db.prepare('SELECT * FROM membership_plans WHERE id = ?').get(id);
  if (!existing) return res.status(404).json({ error: 'Plan not found' });

  const { name, monthlyRate, description, active } = req.body;
  db.prepare(`
    UPDATE membership_plans SET
      name = ?, monthly_rate = ?, description = ?, active = ?
    WHERE id = ?
  `).run(
    name !== undefined ? name : existing.name,
    monthlyRate !== undefined ? monthlyRate : existing.monthly_rate,
    description !== undefined ? description : existing.description,
    active !== undefined ? (active ? 1 : 0) : existing.active,
    id
  );
  res.json(db.prepare('SELECT * FROM membership_plans WHERE id = ?').get(id));
});

// DELETE /api/plans/:id — admin removes a plan (soft delete: just deactivate so past members keep their history)
router.delete('/:id', authRequired, requireRole('admin'), (req, res) => {
  const info = db.prepare('UPDATE membership_plans SET active = 0 WHERE id = ?').run(req.params.id);
  if (info.changes === 0) return res.status(404).json({ error: 'Plan not found' });
  res.status(204).end();
});

module.exports = router;
