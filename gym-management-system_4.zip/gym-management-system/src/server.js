require('dotenv').config();
const path = require('path');
const express = require('express');
const cors = require('cors');

require('./db'); // ensures schema is created on boot
const { startScheduledReminders } = require('./services/reminderService');

const authRoutes = require('./routes/auth');
const memberRoutes = require('./routes/members');
const classRoutes = require('./routes/classes');
const bookingRoutes = require('./routes/bookings');
const paymentRoutes = require('./routes/payments');
const trainerRoutes = require('./routes/trainers');
const reminderRoutes = require('./routes/reminders');
const settingsRoutes = require('./routes/settings');
const planRoutes = require('./routes/plans');

const app = express();
app.use(cors());
app.use(express.json());

app.use('/api/auth', authRoutes);
app.use('/api/members', memberRoutes);
app.use('/api/classes', classRoutes);
app.use('/api/bookings', bookingRoutes);
app.use('/api/payments', paymentRoutes);
app.use('/api/trainers', trainerRoutes);
app.use('/api/reminders', reminderRoutes);
app.use('/api/settings', settingsRoutes);
app.use('/api/plans', planRoutes);

app.get('/api/health', (req, res) => res.json({ ok: true, time: new Date().toISOString() }));

// Serve the static dashboard frontend
app.use(express.static(path.join(__dirname, '..', 'public')));

// Basic error handler
app.use((err, req, res, next) => {
  console.error(err);
  res.status(500).json({ error: 'Internal server error' });
});

const PORT = process.env.PORT || 4000;
app.listen(PORT, () => {
  console.log(`Gym management system running at http://localhost:${PORT}`);
  startScheduledReminders();
});
