/* Ironboard — front-end SPA. No build step: plain fetch + DOM. */

const API = '/api';
let state = {
  token: localStorage.getItem('ib_token') || null,
  user: JSON.parse(localStorage.getItem('ib_user') || 'null'),
  view: null,
  settings: { gym_name: 'Studio', tagline: '' },
};

// ---------------------------------------------------------------- utils --
function $(sel, root = document) { return root.querySelector(sel); }
function el(tag, attrs = {}, children = []) {
  const node = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs)) {
    if (k === 'class') node.className = v;
    else if (k === 'html') node.innerHTML = v;
    else if (k.startsWith('on') && typeof v === 'function') node.addEventListener(k.slice(2), v);
    else node.setAttribute(k, v);
  }
  for (const c of [].concat(children)) {
    if (c == null) continue;
    node.appendChild(typeof c === 'string' ? document.createTextNode(c) : c);
  }
  return node;
}
function toast(message, type = 'ok') {
  let host = $('#toastHost');
  if (!host) { host = el('div', { id: 'toastHost' }); document.body.appendChild(host); }
  const t = el('div', { class: `toast ${type === 'error' ? 'error' : ''}` }, message);
  host.appendChild(t);
  setTimeout(() => t.remove(), 3500);
}
function fmtMoney(n) { return `$${Number(n).toFixed(2)}`; }
function fmtDateTime(iso) {
  const d = new Date(iso);
  return d.toLocaleString(undefined, { weekday: 'short', month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit' });
}
function fmtDate(s) { return s ? new Date(s).toLocaleDateString(undefined, { month: 'short', day: 'numeric', year: 'numeric' }) : '—'; }
function badge(status) { return el('span', { class: `badge badge-${status}` }, status.replace('_', ' ')); }

async function api(path, { method = 'GET', body } = {}) {
  const res = await fetch(`${API}${path}`, {
    method,
    headers: {
      'Content-Type': 'application/json',
      ...(state.token ? { Authorization: `Bearer ${state.token}` } : {}),
    },
    body: body ? JSON.stringify(body) : undefined,
  });
  if (res.status === 204) return null;
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || `Request failed (${res.status})`);
  return data;
}

// ---------------------------------------------------------------- theme --
function applyTheme(theme) {
  document.documentElement.setAttribute('data-theme', theme);
  localStorage.setItem('ib_theme', theme);
  const label = theme === 'light' ? '☀️ Light mode' : '🌙 Dark mode';
  const shortLabel = theme === 'light' ? '☀️ Light' : '🌙 Dark';
  const main = $('#themeToggle'); if (main) main.textContent = label;
  const loginBtn = $('#loginThemeToggle'); if (loginBtn) loginBtn.textContent = shortLabel;
}
function toggleTheme() {
  const current = document.documentElement.getAttribute('data-theme') === 'light' ? 'dark' : 'light';
  applyTheme(current);
}
applyTheme(localStorage.getItem('ib_theme') || 'dark');
$('#themeToggle').addEventListener('click', toggleTheme);
$('#loginThemeToggle').addEventListener('click', toggleTheme);

// ---------------------------------------------------------------- branding --
async function loadBranding() {
  try {
    const s = await api('/settings');
    state.settings = s;
    document.title = `${s.gym_name} — Studio Management`;
    $('#brandGymName').textContent = s.gym_name;
    $('#brandTagline').textContent = s.tagline || 'Welcome back.';
    $('#sidebarGymName').textContent = s.gym_name;
  } catch (err) { /* settings endpoint should always work; fail silently on network hiccup */ }
}
async function loadPlansIntoRegisterForm() {
  const select = $('#regPlan');
  try {
    const plans = await api('/plans');
    select.innerHTML = '';
    if (!plans.length) {
      select.appendChild(el('option', { value: '' }, 'No plans available — contact the front desk'));
      return;
    }
    plans.forEach((p) => select.appendChild(el('option', { value: p.name }, `${p.name} — ${fmtMoney(p.monthly_rate)}/mo`)));
  } catch (err) { select.innerHTML = '<option value="">Could not load plans</option>'; }
}

// ---------------------------------------------------------------- auth --
function persistSession(token, user) {
  state.token = token; state.user = user;
  localStorage.setItem('ib_token', token);
  localStorage.setItem('ib_user', JSON.stringify(user));
}
function clearSession() {
  state.token = null; state.user = null;
  localStorage.removeItem('ib_token'); localStorage.removeItem('ib_user');
}

$('#loginForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  const email = $('#loginEmail').value.trim();
  const password = $('#loginPassword').value;
  $('#loginError').textContent = '';
  try {
    const { token, user } = await api('/auth/login', { method: 'POST', body: { email, password } });
    persistSession(token, user);
    boot();
  } catch (err) { $('#loginError').textContent = err.message; }
});

$('#registerForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  $('#registerError').textContent = '';
  try {
    const { token, user } = await api('/auth/register', {
      method: 'POST',
      body: {
        name: $('#regName').value.trim(),
        email: $('#regEmail').value.trim(),
        phone: $('#regPhone').value.trim(),
        password: $('#regPassword').value,
        membershipPlan: $('#regPlan').value,
      },
    });
    persistSession(token, user);
    boot();
  } catch (err) { $('#registerError').textContent = err.message; }
});

$('#showRegister').addEventListener('click', (e) => {
  e.preventDefault();
  $('#loginForm').classList.toggle('hidden');
  $('#registerForm').classList.toggle('hidden');
  if (!$('#registerForm').classList.contains('hidden')) loadPlansIntoRegisterForm();
});

$('#logoutBtn').addEventListener('click', () => { clearSession(); boot(); });

// ---------------------------------------------------------------- nav --
const NAV = {
  admin: [
    ['dashboard', 'Dashboard'], ['classes', 'Classes'], ['members', 'Members'],
    ['trainers', 'Trainers'], ['payments', 'Payments'], ['reminders', 'Reminders'], ['settings', 'Settings'],
  ],
  trainer: [['myclasses', 'My Classes']],
  member: [['schedule', 'Class Schedule'], ['mybookings', 'My Bookings'], ['mypayments', 'Payments'], ['profile', 'Profile']],
};

function renderNav() {
  const menu = $('#navMenu');
  menu.innerHTML = '';
  const items = NAV[state.user.role] || [];
  items.forEach(([key, label]) => {
    const btn = el('button', {
      class: `nav-item ${state.view === key ? 'active' : ''}`,
      onclick: () => setView(key),
    }, label);
    menu.appendChild(btn);
  });
  $('#userName').textContent = state.user.name;
  $('#userRole').textContent = state.user.role;
}

function setView(key) {
  state.view = key;
  renderNav();
  $('#topbarActions').innerHTML = '';
  const titles = {
    dashboard: 'Dashboard', classes: 'Classes', members: 'Members', trainers: 'Trainers',
    payments: 'Payments', reminders: 'Reminders', settings: 'Settings', myclasses: 'My Classes',
    schedule: 'Class Schedule', mybookings: 'My Bookings', mypayments: 'Payments', profile: 'My Profile',
  };
  $('#viewTitle').textContent = titles[key] || 'Ironboard';
  const root = $('#viewRoot');
  root.innerHTML = '<div class="empty-state">Loading…</div>';
  const renderers = {
    dashboard: renderAdminDashboard, classes: renderClasses, members: renderMembers,
    trainers: renderTrainers, payments: renderPayments, reminders: renderReminders, settings: renderSettings,
    myclasses: renderMyClasses, schedule: renderSchedule, mybookings: renderMyBookings,
    mypayments: renderMyPayments, profile: renderProfile,
  };
  (renderers[key] || (() => { root.innerHTML = '<div class="empty-state">Not found</div>'; }))().catch((err) => {
    root.innerHTML = `<div class="empty-state">${err.message}</div>`;
  });
}

// ---------------------------------------------------------------- modal --
function openModal(title, fields, onSubmit) {
  const overlay = el('div', { class: 'modal-overlay', onclick: (e) => { if (e.target === overlay) overlay.remove(); } });
  const form = el('form', { class: 'modal-form' });
  const inputs = {};
  fields.forEach((f) => {
    let input;
    if (f.type === 'select') {
      input = el('select', { name: f.name }, f.options.map((o) => el('option', { value: o.value }, o.label)));
      if (f.onChange) input.addEventListener('change', () => f.onChange(input.value, inputs));
    } else {
      input = el('input', { type: f.type || 'text', name: f.name, value: f.value ?? '', placeholder: f.placeholder || '', ...(f.required ? { required: 'required' } : {}) });
    }
    inputs[f.name] = input;
    form.appendChild(el('label', {}, [f.label, input]));
  });
  const actions = el('div', { class: 'modal-actions' }, [
    el('button', { type: 'button', class: 'btn btn-ghost btn-block', onclick: () => overlay.remove() }, 'Cancel'),
    el('button', { type: 'submit', class: 'btn btn-primary btn-block' }, 'Save'),
  ]);
  form.appendChild(actions);
  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    const values = {};
    for (const [k, node] of Object.entries(inputs)) values[k] = node.value;
    try {
      await onSubmit(values);
      overlay.remove();
    } catch (err) { toast(err.message, 'error'); }
  });
  overlay.appendChild(el('div', { class: 'modal' }, [el('h3', {}, title), form]));
  document.body.appendChild(overlay);
}

// ---------------------------------------------------------------- admin: dashboard --
async function renderAdminDashboard() {
  const [summary, classes, members] = await Promise.all([
    api('/payments/summary'), api('/classes'), api('/members'),
  ]);
  const root = $('#viewRoot');
  root.innerHTML = '';

  const avgFill = classes.length
    ? Math.round(classes.reduce((s, c) => s + (c.booked_count / c.capacity), 0) / classes.length * 100)
    : 0;

  root.appendChild(el('div', { class: 'kpi-row' }, [
    kpi('Revenue this month', fmtMoney(summary.monthRevenue), 'lime'),
    kpi('Total revenue collected', fmtMoney(summary.totalRevenue)),
    kpi('Pending payments', `${summary.pendingCount}`, 'amber', fmtMoney(summary.pendingAmount) + ' outstanding'),
    kpi('Active members', `${members.filter((m) => m.status === 'active').length}`),
    kpi('Avg. class fill rate', classes.length ? `${avgFill}%` : '—', avgFill >= 70 ? 'lime' : undefined),
  ]));

  if (summary.overdueMembers.length) {
    root.appendChild(panel('Overdue payments', tableFrom(
      ['Member', 'Was due'],
      summary.overdueMembers.map((m) => [m.name, fmtDate(m.next_payment_due)])
    )));
  }

  if (!members.length) {
    root.appendChild(panel('Get started', emptyState('No members yet', 'Add your first member from the Members tab, or share your self-signup link.')));
  }

  root.appendChild(panel('Upcoming classes', classes.slice(0, 6).length
    ? tableFrom(
        ['Class', 'Trainer', 'When', 'Fill'],
        classes.slice(0, 6).map((c) => [c.name, c.trainer_name || '—', fmtDateTime(c.start_time), `${c.booked_count}/${c.capacity}`])
      )
    : emptyState('No classes scheduled', 'Head to Classes to add one.')
  ));
}
function kpi(label, value, tone, sub) {
  return el('div', { class: 'kpi-card' }, [
    el('div', { class: 'kpi-label' }, label),
    el('div', { class: `kpi-value ${tone || ''}` }, value),
    sub ? el('div', { class: 'kpi-sub' }, sub) : null,
  ]);
}
function panel(title, body, headerActions) {
  return el('div', { class: 'panel' }, [
    el('div', { class: 'panel-header' }, [el('h3', {}, title), headerActions || null]),
    el('div', { class: 'panel-body' }, body),
  ]);
}
function emptyState(title, sub) {
  return el('div', { class: 'empty-state' }, [el('strong', {}, title), sub || '']);
}
function tableFrom(headers, rows) {
  return el('table', {}, [
    el('thead', {}, el('tr', {}, headers.map((h) => el('th', {}, h)))),
    el('tbody', {}, rows.map((r) => el('tr', {}, r.map((c) => el('td', {}, c instanceof Node ? c : String(c)))))),
  ]);
}

// ---------------------------------------------------------------- admin: classes --
async function renderClasses() {
  const [classes, trainers] = await Promise.all([api('/classes'), api('/trainers')]);
  const root = $('#viewRoot');
  root.innerHTML = '';

  $('#topbarActions').appendChild(el('button', {
    class: 'btn btn-primary btn-sm',
    onclick: () => openModal('Schedule a class', [
      { name: 'name', label: 'Class name', required: true },
      { name: 'trainerId', label: 'Trainer', type: 'select', options: [{ value: '', label: trainers.length ? '— unassigned —' : 'No trainers yet' }, ...trainers.map((t) => ({ value: t.id, label: t.name }))] },
      { name: 'startTime', label: 'Start time', type: 'datetime-local', required: true },
      { name: 'endTime', label: 'End time', type: 'datetime-local', required: true },
      { name: 'capacity', label: 'Capacity', type: 'number', value: 12 },
      { name: 'location', label: 'Location', value: 'Main Studio' },
    ], async (v) => {
      if (!v.startTime || !v.endTime) throw new Error('Start and end time are required');
      await api('/classes', { method: 'POST', body: {
        name: v.name, trainerId: v.trainerId || null,
        startTime: new Date(v.startTime).toISOString(), endTime: new Date(v.endTime).toISOString(),
        capacity: Number(v.capacity), location: v.location,
      }});
      toast('Class scheduled');
      renderClasses();
    }),
  }, '+ Schedule class'));

  if (!classes.length) {
    root.appendChild(emptyState('No classes yet', trainers.length ? 'Schedule your first class above.' : 'Add a trainer first, then schedule a class.'));
    return;
  }

  root.appendChild(el('div', { class: 'card-grid' }, classes.map((c) => classCard(c, trainers))));
}
function classCard(c, trainers) {
  const fillPct = Math.min(100, Math.round((c.booked_count / c.capacity) * 100));
  const card = el('div', { class: 'class-card' }, [
    el('h4', {}, c.name),
    el('div', { class: 'class-meta' }, `${fmtDateTime(c.start_time)} · ${c.location}`),
    el('div', { class: 'class-meta' }, `Trainer: ${c.trainer_name || 'Unassigned'}`),
    el('div', { class: 'class-fill' }, [
      `${c.booked_count} / ${c.capacity} booked`,
      el('div', { class: 'fill-bar' }, el('div', { class: `fill-bar-inner ${fillPct >= 100 ? 'full' : ''}`, style: `width:${fillPct}%` })),
    ]),
    badge(c.status),
    el('div', { class: 'class-card-actions' }, [
      el('button', { class: 'btn btn-ghost btn-sm', onclick: () => viewRoster(c.id) }, 'Roster'),
      c.status === 'scheduled' ? el('button', {
        class: 'btn btn-danger btn-sm',
        onclick: async () => {
          if (!confirm(`Cancel "${c.name}"?`)) return;
          await api(`/classes/${c.id}`, { method: 'PATCH', body: { status: 'cancelled' } });
          toast('Class cancelled'); renderClasses();
        },
      }, 'Cancel') : null,
    ]),
  ]);
  return card;
}
async function viewRoster(classId) {
  const cls = await api(`/classes/${classId}`);
  function actionsCell(b) {
    const wrap = el('div', { style: 'display:flex; gap:6px;' });
    if (b.status === 'booked') {
      wrap.appendChild(el('button', { class: 'btn btn-lime btn-sm', onclick: async () => { await api(`/bookings/${b.booking_id}`, { method: 'PATCH', body: { status: 'attended' } }); toast('Marked attended'); document.querySelector('.modal-overlay')?.remove(); viewRoster(classId); } }, 'Attended'));
      wrap.appendChild(el('button', { class: 'btn btn-ghost btn-sm', onclick: async () => { await api(`/bookings/${b.booking_id}`, { method: 'PATCH', body: { status: 'no_show' } }); toast('Marked no-show'); document.querySelector('.modal-overlay')?.remove(); viewRoster(classId); } }, 'No-show'));
    }
    return wrap;
  }
  const rows = cls.roster.map((b) => [b.name, b.email, badge(b.status), actionsCell(b)]);
  const overlay = el('div', { class: 'modal-overlay', onclick: (e) => { if (e.target === overlay) overlay.remove(); } });
  overlay.appendChild(el('div', { class: 'modal', style: 'max-width:560px;' }, [
    el('h3', {}, `Roster — ${cls.name}`),
    cls.roster.length ? tableFrom(['Member', 'Email', 'Status', ''], rows) : emptyState('No bookings yet'),
    el('div', { class: 'modal-actions' }, el('button', { class: 'btn btn-ghost btn-block', onclick: () => overlay.remove() }, 'Close')),
  ]));
  document.body.appendChild(overlay);
}

// ---------------------------------------------------------------- admin: members --
async function renderMembers() {
  const [members, plans] = await Promise.all([api('/members'), api('/plans')]);
  const root = $('#viewRoot');
  root.innerHTML = '';

  $('#topbarActions').appendChild(el('button', {
    class: 'btn btn-primary btn-sm',
    onclick: () => openModal('Add member', [
      { name: 'name', label: 'Full name', required: true },
      { name: 'email', label: 'Email', type: 'email', required: true },
      { name: 'phone', label: 'Phone' },
      { name: 'password', label: 'Temporary password', type: 'password', required: true },
      {
        name: 'membershipPlan', label: 'Plan', type: 'select',
        options: plans.length ? plans.map((p) => ({ value: p.name, label: `${p.name} — ${fmtMoney(p.monthly_rate)}/mo` })) : [{ value: 'Custom', label: 'Custom (set rate below)' }],
        onChange: (val, inputs) => { const p = plans.find((x) => x.name === val); if (p && inputs.monthlyRate) inputs.monthlyRate.value = p.monthly_rate; },
      },
      { name: 'monthlyRate', label: 'Monthly rate (USD) — override any time', type: 'number', value: plans[0]?.monthly_rate ?? 0 },
    ], async (v) => {
      await api('/members', { method: 'POST', body: { ...v, monthlyRate: Number(v.monthlyRate) } });
      toast('Member added'); renderMembers();
    }),
  }, '+ Add member'));

  if (!members.length) {
    root.appendChild(emptyState('No members yet', 'Add your first member above — nothing is pre-loaded.'));
    return;
  }

  root.appendChild(tableFrom(
    ['Name', 'Plan', 'Rate', 'Status', 'Next payment', ''],
    members.map((m) => [
      m.name, m.membership_plan, fmtMoney(m.monthly_rate), badge(m.status), fmtDate(m.next_payment_due),
      el('button', { class: 'btn btn-ghost btn-sm', onclick: () => memberDetail(m.id) }, 'View'),
    ])
  ));
}
async function memberDetail(id) {
  const m = await api(`/members/${id}`);
  const overlay = el('div', { class: 'modal-overlay', onclick: (e) => { if (e.target === overlay) overlay.remove(); } });
  overlay.appendChild(el('div', { class: 'modal', style: 'max-width:520px;' }, [
    el('h3', {}, m.name),
    el('div', { class: 'class-meta' }, `${m.email} · ${m.phone || 'no phone'}`),
    el('div', { class: 'class-meta', style: 'margin-bottom:14px;' }, [`${m.membership_plan} · ${fmtMoney(m.monthly_rate)}/mo · `, badge(m.status)]),
    el('h4', { style: 'margin:14px 0 6px; font-size:13px; color:var(--text-muted);' }, 'Recent attendance'),
    m.attendance.length ? tableFrom(['Class', 'When', 'Status'], m.attendance.slice(0, 6).map((a) => [a.class_name, fmtDateTime(a.start_time), badge(a.status)])) : emptyState('No bookings yet'),
    el('h4', { style: 'margin:14px 0 6px; font-size:13px; color:var(--text-muted);' }, 'Payment history'),
    m.payments.length ? tableFrom(['Amount', 'When', 'Status'], m.payments.slice(0, 6).map((p) => [fmtMoney(p.amount), fmtDate(p.paid_at), badge(p.status)])) : emptyState('No payments yet'),
    el('div', { class: 'modal-actions' }, [
      el('button', { class: 'btn btn-ghost btn-block', onclick: () => { openModal(`Update ${m.name}'s rate`, [
        { name: 'monthlyRate', label: 'Monthly rate (USD)', type: 'number', value: m.monthly_rate },
      ], async (v) => { await api(`/members/${id}`, { method: 'PATCH', body: { monthlyRate: Number(v.monthlyRate) } }); toast('Rate updated'); overlay.remove(); renderMembers(); }); } }, 'Adjust rate'),
      el('button', { class: 'btn btn-ghost btn-block', onclick: () => overlay.remove() }, 'Close'),
    ]),
  ]));
  document.body.appendChild(overlay);
}

// ---------------------------------------------------------------- admin: trainers --
async function renderTrainers() {
  const trainers = await api('/trainers');
  const root = $('#viewRoot');
  root.innerHTML = '';
  $('#topbarActions').appendChild(el('button', {
    class: 'btn btn-primary btn-sm',
    onclick: () => openModal('Add trainer', [
      { name: 'name', label: 'Full name', required: true },
      { name: 'email', label: 'Email', type: 'email', required: true },
      { name: 'phone', label: 'Phone' },
      { name: 'password', label: 'Temporary password', type: 'password', required: true },
      { name: 'specialty', label: 'Specialty' },
    ], async (v) => { await api('/trainers', { method: 'POST', body: v }); toast('Trainer added'); renderTrainers(); }),
  }, '+ Add trainer'));

  if (!trainers.length) { root.appendChild(emptyState('No trainers yet', 'Add your first trainer above.')); return; }

  root.appendChild(el('div', { class: 'card-grid' }, trainers.map((t) => el('div', { class: 'class-card' }, [
    el('h4', {}, t.name),
    el('div', { class: 'class-meta' }, t.specialty || 'General fitness'),
    el('div', { class: 'class-meta' }, t.email),
  ]))));
}

// ---------------------------------------------------------------- admin: payments --
async function renderPayments() {
  const [payments, members] = await Promise.all([api('/payments'), api('/members')]);
  const root = $('#viewRoot');
  root.innerHTML = '';
  $('#topbarActions').appendChild(el('button', {
    class: 'btn btn-primary btn-sm',
    onclick: () => openModal('Record payment', [
      { name: 'memberId', label: 'Member', type: 'select', options: members.length ? members.map((m) => ({ value: m.id, label: m.name })) : [{ value: '', label: 'Add a member first' }], required: true },
      { name: 'amount', label: 'Amount (USD)', type: 'number', required: true },
      { name: 'method', label: 'Method', type: 'select', options: [{ value: 'card', label: 'Card' }, { value: 'cash', label: 'Cash' }, { value: 'bank_transfer', label: 'Bank transfer' }] },
      { name: 'status', label: 'Status', type: 'select', options: [{ value: 'paid', label: 'Paid' }, { value: 'pending', label: 'Pending' }] },
    ], async (v) => {
      if (!v.memberId) throw new Error('Select a member');
      await api('/payments', { method: 'POST', body: { ...v, memberId: Number(v.memberId), amount: Number(v.amount) } });
      toast('Payment recorded'); renderPayments();
    }),
  }, '+ Record payment'));

  if (!payments.length) { root.appendChild(emptyState('No payments recorded yet')); return; }

  root.appendChild(tableFrom(
    ['Member', 'Amount', 'Method', 'Status', 'Date', ''],
    payments.map((p) => [
      p.member_name, fmtMoney(p.amount), p.method, badge(p.status), fmtDate(p.paid_at),
      p.status === 'paid' ? el('button', { class: 'btn btn-ghost btn-sm', onclick: async () => { await api(`/payments/${p.id}`, { method: 'PATCH', body: { status: 'refunded' } }); toast('Marked refunded'); renderPayments(); } }, 'Refund') : '',
    ])
  ));
}

// ---------------------------------------------------------------- admin: reminders --
async function renderReminders() {
  const log = await api('/reminders/log');
  const root = $('#viewRoot');
  root.innerHTML = '';
  $('#topbarActions').appendChild(el('button', {
    class: 'btn btn-primary btn-sm',
    onclick: async () => { const r = await api('/reminders/run', { method: 'POST' }); toast(`Sent ${r.classCount} class + ${r.paymentCount} payment reminders`); renderReminders(); },
  }, 'Run reminder sweep now'));

  root.appendChild(panel('How this works', el('div', { class: 'empty-state', style: 'text-align:left; padding:16px 18px;' },
    'Class reminders fire automatically for members booked into a class starting within 24 hours. Payment reminders fire for members whose renewal is due within 3 days. A background job runs this sweep every hour — the button above triggers it on demand. Swap sendNotification() in reminderService.js for a real email/SMS provider to go live.'
  )));

  root.appendChild(panel('Recent reminders sent', log.length
    ? tableFrom(['Type', 'Recipient', 'Message', 'Sent'], log.map((r) => [r.type, r.recipient, r.message, fmtDateTime(r.sent_at)]))
    : emptyState('No reminders sent yet', 'Run a sweep to generate some.')
  ));
}

// ---------------------------------------------------------------- admin: settings --
async function renderSettings() {
  const [settings, plans] = await Promise.all([api('/settings'), api('/plans')]);
  const root = $('#viewRoot');
  root.innerHTML = '';

  root.appendChild(panel('Studio branding', el('form', { class: 'modal-form', style: 'padding:16px 18px;' }, [
    el('label', {}, ['Gym / studio name', el('input', { id: 'settingsGymName', value: settings.gym_name })]),
    el('label', {}, ['Tagline', el('input', { id: 'settingsTagline', value: settings.tagline || '' })]),
    el('button', { type: 'button', class: 'btn btn-primary btn-sm', style: 'width:fit-content;', onclick: async () => {
      await api('/settings', { method: 'PATCH', body: { gymName: $('#settingsGymName').value, tagline: $('#settingsTagline').value } });
      toast('Branding updated'); loadBranding();
    }}, 'Save branding'),
  ])));

  $('#topbarActions').appendChild(el('button', {
    class: 'btn btn-primary btn-sm',
    onclick: () => openModal('Add membership plan', [
      { name: 'name', label: 'Plan name', required: true, placeholder: 'e.g. Elite' },
      { name: 'monthlyRate', label: 'Monthly rate (USD)', type: 'number', required: true },
      { name: 'description', label: 'What it includes (optional)' },
    ], async (v) => {
      await api('/plans', { method: 'POST', body: { name: v.name, monthlyRate: Number(v.monthlyRate), description: v.description } });
      toast('Plan added'); renderSettings();
    }),
  }, '+ Add plan'));

  root.appendChild(panel('Membership plans — priced however you want', plans.length
    ? el('div', { class: 'card-grid', style: 'padding:14px;' }, plans.map((p) => el('div', { class: 'plan-card' }, [
        el('h4', {}, p.name),
        el('div', { class: 'plan-rate' }, `${fmtMoney(p.monthly_rate)}/mo`),
        el('div', { class: 'class-meta' }, p.description || ''),
        el('div', { class: 'class-card-actions' }, [
          el('button', { class: 'btn btn-ghost btn-sm', onclick: () => openModal(`Edit ${p.name}`, [
            { name: 'name', label: 'Plan name', value: p.name },
            { name: 'monthlyRate', label: 'Monthly rate (USD)', type: 'number', value: p.monthly_rate },
            { name: 'description', label: 'Description', value: p.description || '' },
          ], async (v) => { await api(`/plans/${p.id}`, { method: 'PATCH', body: { name: v.name, monthlyRate: Number(v.monthlyRate), description: v.description } }); toast('Plan updated'); renderSettings(); }) }, 'Edit'),
          el('button', { class: 'btn btn-danger btn-sm', onclick: async () => { if (!confirm(`Remove "${p.name}"? Existing members keep their current rate.`)) return; await api(`/plans/${p.id}`, { method: 'DELETE' }); toast('Plan removed'); renderSettings(); } }, 'Remove'),
        ]),
      ])))
    : emptyState('No plans yet', 'Add one above — you can price it however you like.')
  ));
}

// ---------------------------------------------------------------- trainer --
async function renderMyClasses() {
  const t = await api(`/trainers/${state.user.trainerId}`);
  const root = $('#viewRoot');
  root.innerHTML = '';
  if (!t.classes.length) { root.appendChild(emptyState('No classes assigned', 'Ask an admin to assign you to a class.')); return; }
  root.appendChild(el('div', { class: 'card-grid' }, t.classes.map((c) => {
    const fillPct = Math.min(100, Math.round((c.booked_count / c.capacity) * 100));
    return el('div', { class: 'class-card' }, [
      el('h4', {}, c.name),
      el('div', { class: 'class-meta' }, fmtDateTime(c.start_time)),
      el('div', { class: 'class-fill' }, [
        `${c.booked_count} / ${c.capacity} booked`,
        el('div', { class: 'fill-bar' }, el('div', { class: `fill-bar-inner ${fillPct >= 100 ? 'full' : ''}`, style: `width:${fillPct}%` })),
      ]),
      badge(c.status),
      el('div', { class: 'class-card-actions' }, el('button', { class: 'btn btn-ghost btn-sm', onclick: () => viewRoster(c.id) }, 'Roster & attendance')),
    ]);
  })));
}

// ---------------------------------------------------------------- member --
async function renderSchedule() {
  const classes = await api('/classes');
  const root = $('#viewRoot');
  root.innerHTML = '';
  const upcoming = classes.filter((c) => c.status === 'scheduled' && new Date(c.start_time) > new Date());
  if (!upcoming.length) { root.appendChild(emptyState('No upcoming classes', 'Check back soon.')); return; }
  root.appendChild(el('div', { class: 'card-grid' }, upcoming.map((c) => {
    const full = c.booked_count >= c.capacity;
    const fillPct = Math.min(100, Math.round((c.booked_count / c.capacity) * 100));
    return el('div', { class: 'class-card' }, [
      el('h4', {}, c.name),
      el('div', { class: 'class-meta' }, `${fmtDateTime(c.start_time)} · ${c.location}`),
      el('div', { class: 'class-meta' }, `Trainer: ${c.trainer_name || 'TBD'}`),
      el('div', { class: 'class-fill' }, [
        `${c.booked_count} / ${c.capacity} spots filled`,
        el('div', { class: 'fill-bar' }, el('div', { class: `fill-bar-inner ${full ? 'full' : ''}`, style: `width:${fillPct}%` })),
      ]),
      el('div', { class: 'class-card-actions' }, el('button', {
        class: `btn btn-sm ${full ? 'btn-ghost' : 'btn-lime'}`,
        ...(full ? { disabled: 'disabled' } : {}),
        onclick: async () => {
          try { await api('/bookings', { method: 'POST', body: { classId: c.id } }); toast('Booked!'); renderSchedule(); }
          catch (err) { toast(err.message, 'error'); }
        },
      }, full ? 'Class full' : 'Book this class')),
    ]);
  })));
}
async function renderMyBookings() {
  const m = await api(`/members/${state.user.memberId}`);
  const root = $('#viewRoot');
  root.innerHTML = '';
  if (!m.attendance.length) { root.appendChild(emptyState('No bookings yet', 'Book a class from the Class Schedule tab.')); return; }
  root.appendChild(tableFrom(
    ['Class', 'When', 'Status', ''],
    m.attendance.map((a) => [
      a.class_name, fmtDateTime(a.start_time), badge(a.status),
      a.status === 'booked' ? el('button', { class: 'btn btn-ghost btn-sm', onclick: async () => { await api(`/bookings/${a.id}`, { method: 'PATCH', body: { status: 'cancelled' } }); toast('Booking cancelled'); renderMyBookings(); } }, 'Cancel') : '',
    ])
  ));
}
async function renderMyPayments() {
  const payments = await api('/payments');
  const root = $('#viewRoot');
  root.innerHTML = '';
  root.appendChild(payments.length
    ? tableFrom(['Amount', 'Method', 'Status', 'Date'], payments.map((p) => [fmtMoney(p.amount), p.method, badge(p.status), fmtDate(p.paid_at)]))
    : emptyState('No payment history yet'));
}
async function renderProfile() {
  const m = await api(`/members/${state.user.memberId}`);
  const root = $('#viewRoot');
  root.innerHTML = '';
  root.appendChild(panel('Membership', el('div', { style: 'padding:14px 18px; display:flex; flex-direction:column; gap:8px;' }, [
    el('div', {}, [el('strong', {}, m.membership_plan), ` — ${fmtMoney(m.monthly_rate)}/mo`]),
    el('div', { class: 'class-meta' }, `Member since ${fmtDate(m.join_date)}`),
    el('div', { class: 'class-meta' }, `Next payment due ${fmtDate(m.next_payment_due)}`),
    badge(m.status),
  ])));
  root.appendChild(panel('Contact info', el('form', { class: 'modal-form', style: 'padding:14px 18px;' }, [
    el('label', {}, ['Phone', el('input', { id: 'profilePhone', value: m.phone || '' })]),
    el('button', { type: 'button', class: 'btn btn-primary btn-sm', style: 'width:fit-content;', onclick: async () => {
      await api(`/members/${state.user.memberId}`, { method: 'PATCH', body: { phone: $('#profilePhone').value } });
      toast('Profile updated');
    }}, 'Save changes'),
  ])));
}

// ---------------------------------------------------------------- boot --
async function boot() {
  await loadBranding();
  if (state.token && state.user) {
    $('#loginScreen').classList.add('hidden');
    $('#appShell').classList.remove('hidden');
    renderNav();
    const defaultView = { admin: 'dashboard', trainer: 'myclasses', member: 'schedule' }[state.user.role];
    setView(defaultView);
  } else {
    $('#appShell').classList.add('hidden');
    $('#loginScreen').classList.remove('hidden');
  }
}
boot();
